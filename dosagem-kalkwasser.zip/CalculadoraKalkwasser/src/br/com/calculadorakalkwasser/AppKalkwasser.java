package br.com.calculadorakalkwasser;

// Importa a biblioteca gr�fica
import javax.swing.JOptionPane;


public class AppKalkwasser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Inst�ncia de objetos
		CalculadoraKalkwasses usuario = new CalculadoraKalkwasses();
		
		// Declara��o de variaveis
		
		String C;
		String v;
		// Declara��o de array (vetor) 
		
		Object[] opcao = {"Informar dados", "mostrar dados", "dosagem","sair",};
		Object selecionarOpcao;
		
		do {
		// Exibe as op��es para o usu�rio
		
		selecionarOpcao = JOptionPane.showInputDialog(null, "Escolha uma op��o:", "Calculadora de kalkwasser:", JOptionPane.INFORMATION_MESSAGE, null, opcao, opcao[0]);
		if(selecionarOpcao == "Informar dados") {
		
		
		// Input dos n�o Strings 
			
		v = JOptionPane.showInputDialog("Informe o volume de �gua do seu aqu�rio:");
		C = JOptionPane.showInputDialog("Informe o consumo de kh do seu aqu�rio:");
		
		
		// converter de String para int e double
		
		usuario.setV(Double.parseDouble(v));
		usuario.setC(Double.parseDouble(C));
		
		//Mensagen de confirma��o
		
		JOptionPane.showMessageDialog(null, "Dados informados com sucesso");
		}
		
		 
		else if (selecionarOpcao == "mostrar dados") {
		//sa�da de dados 
		
		JOptionPane.showMessageDialog(null,"volume do aqu�rio: " + usuario.getV() + ".\nquantidade consumida de carbonatos: " + usuario.getC()  + ".");
		}
		else if (selecionarOpcao == "dosagem") {
			JOptionPane.showMessageDialog(null,"dosagem: " + String.format("%.2f",usuario.dosagemKalk()) + (usuario.dosagemKalk()));	
		}
		
		else 
			System.exit(0);
		
		} while (selecionarOpcao != "sair");
		
	}
}

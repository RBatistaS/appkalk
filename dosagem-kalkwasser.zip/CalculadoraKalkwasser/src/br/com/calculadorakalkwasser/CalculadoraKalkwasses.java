package br.com.calculadorakalkwasser;

public class CalculadoraKalkwasses {
	
	private double v;
	private double C;
    double solucao = 114;
     
	public CalculadoraKalkwasses() {
		// TODO Auto-generated constructor stub
	}

	public double getV() {
		return v;
	}

	public void setV(double v) {
		this.v = v;
	}

	public double getC() {
		return C;
	}

	public void setC(double C) {
		this.C = C;
	}
	
	public double dosagemKalk() {
		return (this.v * this.C) / this.solucao;
	}

}
